// Studio character. Undefined uses built-in vector Byte.
// scripts/atlas_rig.py <atlas> --install replaces this selection with atlasHero(rig).
import type {HeroRender} from './HeroSticker';

export const HERO: HeroRender | undefined = undefined;
