# Awais Cartoon Studio

Say **"Cartoon"** in [Claude Code](https://code.claude.com/docs/en/overview) and turn an idea into a vertical animated explainer — with your own character, visual style, and voice. Windows open, the cursor clicks, words trigger actions, and a sticker character stays with you throughout.

Scenes, interfaces, captions, and transitions are built with [Remotion](https://www.remotion.dev). Text stays editable and revisions are code changes. No stock footage is needed. You can generate a character sheet from your own photo once, then animate it in code.

▶ [Watch the demo](https://drive.google.com/) *(replace with your own demo link before selling)*

## What's in the pack

```text
Awais-Cartoon-Studio/
├── README.md               ← this file
├── LICENSE                 ← MIT license (see Attribution below)
├── SETUP-GUIDE.pdf         ← step-by-step buyer guide
└── .claude/skills/cartoon/ ← the skill you install
    ├── SKILL.md            Setup, script approval, production, delivery
    ├── method.md           Word-driven storyboard and animation workflow
    └── kit/                Remotion starter project + helper scripts
```

## Install (buyers)

Run this in your project folder (the folder that contains your `.claude` directory):

```powershell
# Windows (PowerShell)
Copy-Item -Recurse -Force .\awais-cartoon-studio\.claude\skills\cartoon .\.claude\skills\cartoon
```

```bash
# macOS / Linux
cp -R awais-cartoon-studio/.claude/skills/cartoon .claude/skills/cartoon
```

For every project, place the `cartoon` skill folder in `~/.claude/skills/`. On first use, Claude creates a working studio at `cartoon/` in your project and walks you through setup. The installed skill stays untouched.

## First run

Open Claude Code in the project and say **"Cartoon."** Progress is saved in `cartoon/setup.json`, so you can stop and resume.

1. **Choose your language and niche.** Share your Instagram or TikTok profile, or describe what you make.
2. **Choose a visual style.** Share a reference video or use the built-in cobalt-on-graph-paper look.
3. **Choose a character.** Use your own photo to make a pose sheet in ChatGPT or Gemini, use an image API, or keep **Byte**, the built-in vector robot.
4. **Choose a voice.** Record each script yourself or use an ElevenLabs voice clone you have permission to use.
5. **Check the environment.** Claude checks Node, npm, Python, and ffmpeg, then installs the studio dependencies.
6. **Optional: connect your Telegram bot.** Receive finished files privately. You publish them yourself.

Then try:

- **"Cartoon"** — start from your niche.
- **"Cartoon from this link…"** — use a specific reference video.
- **"Cartoon about…"** — start with your own topic.

Claude shows the full script for approval before narration. Then it creates the voice track, maps actions to words, builds scenes, reviews frames, and exports the MP4 with a suggested description.

## Requirements

- Claude Code (Anthropic) or a compatible Claude agent.
- Node.js 18+ and npm. Remotion downloads its headless browser.
- Python 3.9+; the helper scripts use the standard library unless noted.
- ffmpeg and ffprobe for audio, frame sheets, and Telegram compression.
- Optional: `pip install faster-whisper` for local word timing, and `pip install pillow` for faster atlas processing.
- An internet connection for Google Fonts during rendering.

Optional API keys live in `cartoon/.env`: `OPENAI_API_KEY` or `GEMINI_API_KEY` for a custom character, `ELEVENLABS_API_KEY` for voice synthesis, and `TELEGRAM_BOT_TOKEN` for your own bot. Both `.env` and `setup.json` are ignored by Git. Photos are sent only to the image provider you select.

## Try the bundled demo

The demo has synthetic timing and event sounds, with no generated narration.

```bash
cd .claude/skills/cartoon/kit
npm i
npx remotion studio src/index.ts
python3 scripts/sfx.py examples/demo/props.json examples/demo/sfx.json -o public/demo-sfx.wav
npx remotion render src/index.ts Demo out/demo.mp4
```

## Attribution

This product is based on open-source code released under the MIT License. The original copyright notice and license are preserved in [LICENSE](LICENSE) and must stay in every copy or redistribution.

## License

The code is MIT licensed; see [LICENSE](LICENSE). Remotion has its [own license](https://www.remotion.dev/license) — check its current terms for your use. Bundled font families use the SIL Open Font License.

---

**Awais Cartoon Studio**
